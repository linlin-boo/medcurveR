
# medcurveR

`medcurveR` is an R package for **tail-aware medical plotting**. It is designed for software-paper style submission and focuses on two figure families that appear repeatedly in clinical, epidemiologic, and observational research:

- Kaplan-Meier curves with sparse-tail risk tables
- Restricted cubic spline (RCS) curves with sparse-tail display diagnostics

## What is new?

The package is not only a styling wrapper. It adds four software-paper oriented pieces:

1. **Rule-based sparse-tail handling** instead of ad hoc manual trimming.
2. **Standardized tail diagnostics** via `tail_profile()` and `tail_profile_table()`.
3. **Comparison workflows** via `km_compare_tail()` and `rcs_compare_tail()`.
4. **Weighted-model compatibility** through optional case weights in `km_pretty()` and `rcs_pretty()`.

## Install

```r
install.packages(c("ggplot2", "survival", "patchwork", "Hmisc"))
install.packages("medcurveR_0.1.0.tar.gz", repos = NULL, type = "source")
```

## Minimal example

```r
library(medcurveR)

d <- sim_surv_data(400)

p_km <- km_pretty(
  data = d,
  time = "time",
  event = "event",
  group = "group",
  min_at_risk = 20,
  cut_mode = "median",
  title = "Overall survival by tertile"
)

out_rcs <- rcs_pretty(
  data = d,
  x = "marker",
  time = "time",
  event = "event",
  covariates = c("age", "sex"),
  family = "cox",
  min_tail_n = 15,
  tail_rule = "hybrid",
  title = "Spline association between marker and survival"
)

p_km
out_rcs$plot

tail_profile_table(attr(p_km, "tail_profile"), bind = TRUE)
tail_profile_table(out_rcs, bind = TRUE)
```

## One-shot manuscript output

After installation, run the script below to generate manuscript-style figures and CSV tables in one pass:

```r
source(system.file("scripts", "generate_paper_figures.R", package = "medcurveR"))
```

It will create a `medcurveR_paper_outputs/` folder containing:

- KM main figure
- Weighted KM figure
- KM comparison figure
- RCS main figure
- RCS comparison figure
- Tail diagnostic CSV files
- Session information
