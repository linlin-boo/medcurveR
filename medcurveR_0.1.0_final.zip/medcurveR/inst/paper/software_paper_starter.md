
# medcurveR software paper starter

## Suggested title
medcurveR: Tail-aware visualization and sparse-tail diagnostics for Kaplan-Meier and restricted cubic spline figures in medical research

## Core novelty statements
1. Rule-based sparse-tail handling replaces ad hoc visual trimming.
2. Standardized diagnostics expose how display ranges were chosen.
3. Comparison workflows document full-range, default, and tail-aware displays.
4. Weighted-compatible plotting extends the workflow beyond unweighted examples.

## Suggested figure set
- Figure 1. Tail-aware Kaplan-Meier plot with risk table.
- Figure 2. Weighted Kaplan-Meier plot.
- Figure 3. KM comparison: no truncation, default, tail-aware.
- Figure 4. Tail-aware RCS plot with excluded-tail shading.
- Figure 5. RCS comparison: full range vs tail-aware.

## Suggested supplementary tables
- Table S1. KM tail-profile diagnostics.
- Table S2. Weighted KM tail-profile diagnostics.
- Table S3. KM comparison summary.
- Table S4. RCS tail-profile diagnostics.
- Table S5. RCS comparison summary.
