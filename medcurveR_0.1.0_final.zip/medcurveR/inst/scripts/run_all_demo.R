
# Quick start wrapper
source(system.file("scripts", "generate_paper_figures.R", package = "medcurveR"))
