
# medcurveR manuscript output script
# Generates figures and diagnostic tables for a software-paper style submission.

suppressPackageStartupMessages({
  library(medcurveR)
  library(ggplot2)
})

out_dir <- file.path(getwd(), "medcurveR_paper_outputs")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

set.seed(20260415)
d <- sim_surv_data(400)

# Figure 1: KM main
p_km <- km_pretty(
  data = d,
  time = "time",
  event = "event",
  group = "group",
  min_at_risk = 20,
  cut_mode = "median",
  title = "Overall survival by tertile"
)

ggsave(file.path(out_dir, "Figure1_KM_tail_aware.png"), p_km, width = 9, height = 5.8, dpi = 300)

# Figure 2: weighted KM
p_km_w <- km_pretty(
  data = d,
  time = "time",
  event = "event",
  group = "group",
  weights = "weights",
  min_at_risk = 20,
  cut_mode = "median",
  title = "Weighted KM example"
)

ggsave(file.path(out_dir, "Figure2_KM_weighted.png"), p_km_w, width = 9, height = 5.8, dpi = 300)

# Figure 3: KM comparison
km_cmp <- km_compare_tail(
  data = d,
  time = "time",
  event = "event",
  group = "group",
  min_at_risk = 20,
  cut_mode = "median"
)

ggsave(file.path(out_dir, "Figure3_KM_comparison.png"), km_cmp$plot, width = 15, height = 5.2, dpi = 300)

# Figure 4: RCS main
rcs_out <- rcs_pretty(
  data = d,
  x = "marker",
  time = "time",
  event = "event",
  covariates = c("age", "sex"),
  family = "cox",
  min_tail_n = 15,
  tail_rule = "hybrid",
  title = "Spline association between marker and survival"
)

ggsave(file.path(out_dir, "Figure4_RCS_tail_aware.png"), rcs_out$plot, width = 9.5, height = 6.2, dpi = 300)

# Figure 5: RCS comparison
rcs_cmp <- rcs_compare_tail(
  data = d,
  x = "marker",
  time = "time",
  event = "event",
  covariates = c("age", "sex"),
  family = "cox",
  min_tail_n = 15,
  tail_rule = "hybrid"
)

ggsave(file.path(out_dir, "Figure5_RCS_comparison.png"), rcs_cmp$plot, width = 12.5, height = 7.5, dpi = 300)

# Tables
write.csv(tail_profile_table(attr(p_km, "tail_profile"), bind = TRUE), file.path(out_dir, "TableS1_KM_tail_profile.csv"), row.names = FALSE)
write.csv(tail_profile_table(attr(p_km_w, "tail_profile"), bind = TRUE), file.path(out_dir, "TableS2_KM_weighted_tail_profile.csv"), row.names = FALSE)
write.csv(km_cmp$table, file.path(out_dir, "TableS3_KM_comparison.csv"), row.names = FALSE)
write.csv(tail_profile_table(rcs_out, bind = TRUE), file.path(out_dir, "TableS4_RCS_tail_profile.csv"), row.names = FALSE)
write.csv(rcs_cmp$table, file.path(out_dir, "TableS5_RCS_comparison.csv"), row.names = FALSE)

# Session info
writeLines(utils::capture.output(sessionInfo()), file.path(out_dir, "sessionInfo.txt"))

message("Done. Outputs saved to: ", out_dir)
