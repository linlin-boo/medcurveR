.compute_survival_tail_profile <- function(fit, min_n = 10, cut_mode = c("all", "any", "median")) {
  cut_mode <- match.arg(cut_mode)
  s <- summary(fit)
  strata <- if (is.null(s$strata)) rep("All", length(s$time)) else as.character(s$strata)
  if (length(s$time) == 0) {
    by_group <- data.frame(strata = character(), clean_strata = character(), cutoff_time = numeric(), end_n_risk = numeric(), end_n_event = numeric(), below_threshold_time = numeric(), stringsAsFactors = FALSE)
    summary_tbl <- data.frame(type = "survival", min_n = min_n, cut_mode = cut_mode, final_cutoff = NA_real_, total_events_after_cutoff = NA_real_, min_end_n_risk = NA_real_, stringsAsFactors = FALSE)
    return(list(type = "survival", summary = summary_tbl, by_group = by_group, event_sparsity = by_group))
  }

  df <- data.frame(
    time = s$time,
    n.risk = s$n.risk,
    n.event = s$n.event,
    strata = strata,
    stringsAsFactors = FALSE
  )
  split_df <- split(df, df$strata)
  by_group <- do.call(rbind, lapply(split_df, function(dfi) {
    ok <- dfi$time[dfi$n.risk >= min_n]
    cutoff <- if (length(ok) == 0) 0 else max(ok, na.rm = TRUE)
    end_idx <- if (cutoff <= 0) 1 else max(which(dfi$time <= cutoff))
    below_idx <- which(dfi$n.risk < min_n)
    below_time <- if (length(below_idx) == 0) NA_real_ else dfi$time[min(below_idx)]
    data.frame(
      strata = dfi$strata[1],
      clean_strata = .clean_strata_labels(dfi$strata[1]),
      cutoff_time = cutoff,
      end_n_risk = dfi$n.risk[end_idx],
      end_n_event = sum(dfi$n.event[dfi$time > cutoff], na.rm = TRUE),
      below_threshold_time = below_time,
      stringsAsFactors = FALSE
    )
  }))

  candidate_times <- by_group$cutoff_time[is.finite(by_group$cutoff_time)]
  final_cutoff <- if (length(candidate_times) == 0) NA_real_ else {
    if (cut_mode == "all") min(candidate_times, na.rm = TRUE) else if (cut_mode == "any") max(candidate_times, na.rm = TRUE) else stats::median(candidate_times, na.rm = TRUE)
  }

  event_sparsity <- do.call(rbind, lapply(split_df, function(dfi) {
    data.frame(
      strata = dfi$strata[1],
      clean_strata = .clean_strata_labels(dfi$strata[1]),
      n_points_total = nrow(dfi),
      n_points_after_cutoff = sum(dfi$time > final_cutoff, na.rm = TRUE),
      n_events_after_cutoff = sum(dfi$n.event[dfi$time > final_cutoff], na.rm = TRUE),
      min_n_risk_after_cutoff = if (any(dfi$time > final_cutoff)) min(dfi$n.risk[dfi$time > final_cutoff], na.rm = TRUE) else NA_real_,
      stringsAsFactors = FALSE
    )
  }))

  summary_tbl <- data.frame(
    type = "survival",
    min_n = min_n,
    cut_mode = cut_mode,
    final_cutoff = final_cutoff,
    total_events_after_cutoff = sum(event_sparsity$n_events_after_cutoff, na.rm = TRUE),
    min_end_n_risk = min(by_group$end_n_risk, na.rm = TRUE),
    stringsAsFactors = FALSE
  )

  list(
    type = "survival",
    summary = summary_tbl,
    by_group = by_group,
    event_sparsity = event_sparsity,
    suggested_max_time = final_cutoff
  )
}

.compute_continuous_tail_profile <- function(x, weights = NULL, min_n = 10, trim_quantile = c(0.01, 0.99), rule = c("hybrid", "quantile", "count")) {
  rule <- match.arg(rule)
  x <- x[is.finite(x)]
  if (length(x) == 0) stop("`x` has no finite values.", call. = FALSE)
  o <- order(x)
  x <- x[o]
  if (!is.null(weights)) {
    weights <- weights[o]
  }

  q_bounds <- stats::quantile(x, probs = trim_quantile, na.rm = TRUE, names = FALSE)
  count_bounds <- if (length(x) >= 2 * min_n + 1) c(x[min_n], x[length(x) - min_n + 1]) else range(x, na.rm = TRUE)
  bounds <- if (rule == "quantile") q_bounds else if (rule == "count") count_bounds else c(max(q_bounds[1], count_bounds[1]), min(q_bounds[2], count_bounds[2]))

  in_display <- x >= bounds[1] & x <= bounds[2]
  left_tail <- x < bounds[1]
  right_tail <- x > bounds[2]

  if (is.null(weights)) {
    w_left <- sum(left_tail)
    w_right <- sum(right_tail)
    w_in <- sum(in_display)
    total_w <- length(x)
  } else {
    w_left <- sum(weights[left_tail])
    w_right <- sum(weights[right_tail])
    w_in <- sum(weights[in_display])
    total_w <- sum(weights)
  }

  summary_tbl <- data.frame(
    type = "continuous",
    min_n = min_n,
    rule = rule,
    lower_bound = bounds[1],
    upper_bound = bounds[2],
    lower_quantile = q_bounds[1],
    upper_quantile = q_bounds[2],
    lower_count_bound = count_bounds[1],
    upper_count_bound = count_bounds[2],
    left_tail_n = sum(left_tail),
    right_tail_n = sum(right_tail),
    in_display_n = sum(in_display),
    left_tail_weight = w_left,
    right_tail_weight = w_right,
    in_display_weight = w_in,
    total_weight = total_w,
    stringsAsFactors = FALSE
  )

  bins <- stats::quantile(x, probs = seq(0, 1, length.out = 11), na.rm = TRUE, names = FALSE)
  bins <- unique(bins)
  if (length(bins) < 3) bins <- pretty(range(x), n = 6)
  cut_x <- cut(x, breaks = bins, include.lowest = TRUE)
  sparsity <- aggregate(list(n = rep(1, length(x))), list(bin = cut_x), sum)
  if (is.null(weights)) {
    sparsity$weighted_n <- sparsity$n
  } else {
    sparsity_w <- aggregate(list(weighted_n = weights), list(bin = cut_x), sum)
    sparsity$weighted_n <- sparsity_w$weighted_n
  }

  list(
    type = "continuous",
    summary = summary_tbl,
    bin_sparsity = sparsity,
    suggested_bounds = bounds,
    quantile_bounds = q_bounds,
    count_bounds = count_bounds
  )
}

#' Tail profile diagnostics for survival time or continuous exposure
#'
#' Returns standardized sparse-tail diagnostics that can be reported in methods,
#' supplements, or comparison tables.
#'
#' @param x Optional numeric exposure vector.
#' @param fit Optional `survival::survfit` object.
#' @param weights Optional numeric weights for continuous-exposure diagnostics.
#' @param min_n Minimum retained count used for sparse-tail handling.
#' @param cut_mode Aggregation rule for survival-tail suggestions.
#' @param trim_quantile Quantiles used when `x` is supplied.
#' @param rule Rule used to derive continuous display bounds.
#'
#' @return A list with standardized summary tables.
#' @export
#'
#' @examples
#' d <- sim_surv_data(200)
#' fit <- survival::survfit(survival::Surv(time, event) ~ group, data = d)
#' tail_profile(fit = fit, min_n = 20)
#' tail_profile(x = d$marker, min_n = 15)
tail_profile <- function(x = NULL,
                         fit = NULL,
                         weights = NULL,
                         min_n = 10,
                         cut_mode = c("all", "any", "median"),
                         trim_quantile = c(0.01, 0.99),
                         rule = c("hybrid", "quantile", "count")) {
  if (!is.null(fit)) {
    return(.compute_survival_tail_profile(fit = fit, min_n = min_n, cut_mode = cut_mode))
  }
  if (!is.null(x)) {
    return(.compute_continuous_tail_profile(x = x, weights = weights, min_n = min_n, trim_quantile = trim_quantile, rule = rule))
  }
  stop("Supply either `fit` or `x`.", call. = FALSE)
}
