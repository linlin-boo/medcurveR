#' Journal-style theme for medical figures
#'
#' @param base_size Base font size.
#' @param base_family Base font family.
#' @param legend Legend position.
#'
#' @return A ggplot theme object.
#' @export
journal_theme_med <- function(base_size = 12, base_family = "sans", legend = "right") {
  ggplot2::theme_bw(base_size = base_size, base_family = base_family) +
    ggplot2::theme(
      panel.grid = ggplot2::element_blank(),
      plot.background = ggplot2::element_rect(fill = "white", colour = NA),
      panel.background = ggplot2::element_rect(fill = "white", colour = NA),
      panel.border = ggplot2::element_rect(linewidth = 0.6, colour = "black"),
      axis.line = ggplot2::element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = ggplot2::element_line(linewidth = 0.35, colour = "black"),
      axis.title = ggplot2::element_text(face = "bold", colour = "black"),
      axis.text = ggplot2::element_text(colour = "black"),
      plot.title = ggplot2::element_text(face = "bold", hjust = 0, size = ggplot2::rel(1.15)),
      plot.subtitle = ggplot2::element_text(hjust = 0),
      legend.position = legend,
      legend.title = ggplot2::element_text(face = "bold"),
      legend.background = ggplot2::element_blank(),
      legend.key = ggplot2::element_blank(),
      strip.background = ggplot2::element_rect(fill = "grey95", colour = "black"),
      strip.text = ggplot2::element_text(face = "bold")
    )
}
