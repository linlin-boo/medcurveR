.validate_columns <- function(data, cols) {
  miss <- setdiff(cols, names(data))
  if (length(miss) > 0) {
    stop("Missing columns: ", paste(miss, collapse = ", "), call. = FALSE)
  }
}

.mode_value <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) return(NA)
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

.typical_value <- function(x) {
  if (is.numeric(x)) stats::median(x, na.rm = TRUE) else .mode_value(x)
}

.pretty_breaks <- function(max_time, n = 6) {
  if (!is.finite(max_time) || max_time <= 0) return(c(0, 1))
  pretty(c(0, max_time), n = n)
}

.clean_strata_labels <- function(x) {
  x <- as.character(x)
  x <- sub("^.*=", "", x)
  x <- gsub(",", " / ", x, fixed = TRUE)
  x
}

.color_values <- function(n, palette = NULL) {
  if (!is.null(palette)) {
    if (length(palette) < n) stop("Palette has fewer colors than groups.", call. = FALSE)
    return(palette[seq_len(n)])
  }
  grDevices::hcl.colors(n, palette = "Dark 3")
}

.resolve_weights <- function(data, weights = NULL) {
  if (is.null(weights)) return(NULL)
  if (length(weights) == 1 && is.character(weights)) {
    .validate_columns(data, weights)
    w <- data[[weights]]
  } else {
    w <- weights
  }
  if (length(w) != nrow(data)) stop("`weights` must have the same length as rows in `data`.", call. = FALSE)
  w <- as.numeric(w)
  if (any(!is.finite(w))) stop("`weights` must be finite.", call. = FALSE)
  if (any(w < 0)) stop("`weights` must be non-negative.", call. = FALSE)
  w
}

.format_nrisk <- function(x) {
  if (all(abs(x - round(x)) < 1e-8, na.rm = TRUE)) {
    as.character(round(x))
  } else {
    sprintf("%.1f", x)
  }
}

.reference_value <- function(x, ref = c("median", "mean", "zero", "value"), ref_value = NULL) {
  ref <- match.arg(ref)
  if (ref == "median") return(stats::median(x, na.rm = TRUE))
  if (ref == "mean") return(mean(x, na.rm = TRUE))
  if (ref == "zero") return(0)
  if (is.null(ref_value)) stop("`ref_value` must be supplied when ref = 'value'.", call. = FALSE)
  ref_value
}

.make_basis <- function(x, nk = 4, knots = NULL) {
  if (is.null(knots)) {
    basis <- Hmisc::rcspline.eval(x, nk = nk, inclx = TRUE)
    knots <- attr(basis, "knots")
  } else {
    basis <- Hmisc::rcspline.eval(x, knots = knots, inclx = TRUE)
  }
  basis <- as.data.frame(basis)
  names(basis) <- paste0("rcs", seq_len(ncol(basis)))
  attr(basis, "knots") <- knots
  basis
}

.make_prediction_data <- function(data, x, covariates, grid) {
  newdata <- data.frame(row.names = seq_along(grid))
  newdata[[x]] <- grid
  if (!is.null(covariates) && length(covariates) > 0) {
    for (v in covariates) {
      val <- .typical_value(data[[v]])
      if (is.factor(data[[v]])) {
        newdata[[v]] <- factor(rep(as.character(val), length(grid)), levels = levels(data[[v]]))
      } else {
        newdata[[v]] <- rep(val, length(grid))
      }
    }
  }
  newdata
}

.align_matrix <- function(X, coef_names) {
  miss <- setdiff(coef_names, colnames(X))
  if (length(miss) > 0) {
    add <- matrix(0, nrow = nrow(X), ncol = length(miss))
    colnames(add) <- miss
    X <- cbind(X, add)
  }
  X[, coef_names, drop = FALSE]
}

.model_compare_p <- function(fit0, fit1, family) {
  if (family == "linear") {
    a <- stats::anova(fit0, fit1)
    return(a$`Pr(>F)`[2])
  }
  ll0 <- as.numeric(stats::logLik(fit0))
  ll1 <- as.numeric(stats::logLik(fit1))
  df0 <- attr(stats::logLik(fit0), "df")
  df1 <- attr(stats::logLik(fit1), "df")
  chisq <- 2 * (ll1 - ll0)
  ddf <- df1 - df0
  stats::pchisq(chisq, df = ddf, lower.tail = FALSE)
}

.placeholder_plot <- function(title, subtitle = NULL, base_family = "sans") {
  ggplot2::ggplot(data.frame(x = 0, y = 0), ggplot2::aes(.data$x, .data$y)) +
    ggplot2::geom_text(label = subtitle %||% "Unavailable", family = base_family, size = 4.5) +
    ggplot2::labs(title = title, x = NULL, y = NULL) +
    ggplot2::theme_void() +
    ggplot2::theme(plot.title = ggplot2::element_text(face = "bold", hjust = 0))
}

`%||%` <- function(x, y) if (is.null(x)) y else x
