
#' Standardize tail-profile diagnostics into export-ready tables
#'
#' Flattens the object returned by [tail_profile()] into data frames that can be
#' written to CSV or included in supplementary materials.
#'
#' @param profile A list returned by [tail_profile()], or a plot/list object with a
#'   `tail_profile` attribute or component.
#' @param which Which table(s) to return.
#' @param bind Logical; if `TRUE`, combine all available tables into one data frame
#'   with a `section` column.
#'
#' @return A named list of data frames, or a single data frame when `bind = TRUE`.
#' @export
#'
#' @examples
#' d <- sim_surv_data(200)
#' fit <- survival::survfit(survival::Surv(time, event) ~ group, data = d)
#' tp <- tail_profile(fit = fit, min_n = 20)
#' tail_profile_table(tp)

tail_profile_table <- function(profile,
                               which = c("summary", "by_group", "event_sparsity", "bin_sparsity"),
                               bind = FALSE) {
  if (inherits(profile, 'ggplot') || inherits(profile, 'patchwork')) {
    profile <- attr(profile, 'tail_profile')
  }
  if (is.list(profile) && !is.null(profile$tail_profile)) {
    profile <- profile$tail_profile
  }
  if (!is.list(profile)) stop('`profile` must be a tail_profile()-like object.', call. = FALSE)

  out <- list()
  for (nm in which) {
    if (!is.null(profile[[nm]]) && is.data.frame(profile[[nm]])) {
      out[[nm]] <- profile[[nm]]
    }
  }
  if (length(out) == 0) stop('No requested data-frame components found in `profile`.', call. = FALSE)

  if (!bind) return(out)

  common_cols <- unique(unlist(lapply(out, names)))
  out2 <- lapply(names(out), function(nm) {
    df <- out[[nm]]
    miss <- setdiff(common_cols, names(df))
    if (length(miss) > 0) {
      for (m in miss) df[[m]] <- NA
    }
    df <- df[, common_cols, drop = FALSE]
    df$section <- nm
    df
  })
  do.call(rbind, out2)
}
