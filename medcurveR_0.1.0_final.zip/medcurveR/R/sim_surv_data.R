#' Simulate survival data for package examples
#'
#' @param n Number of observations.
#' @param seed Random seed.
#'
#' @return A data frame with survival time, event, tertile group, marker, age, sex, and weights.
#' @export
sim_surv_data <- function(n = 400, seed = 123) {
  set.seed(seed)
  age <- round(stats::rnorm(n, mean = 60, sd = 10), 1)
  sex <- factor(stats::rbinom(n, 1, 0.48), labels = c("Female", "Male"))
  marker <- stats::rlnorm(n, meanlog = 1.8, sdlog = 0.35)
  lp <- 0.28 * scale(marker)[, 1] + 0.12 * scale(age)[, 1] + 0.12 * (sex == "Male")
  base_time <- stats::rexp(n, rate = 0.08 * exp(lp))
  censor <- stats::runif(n, min = 2, max = 8)
  time <- pmin(base_time, censor)
  event <- as.integer(base_time <= censor)
  group <- cut(marker, breaks = stats::quantile(marker, probs = c(0, 1/3, 2/3, 1)), include.lowest = TRUE, labels = c("T1", "T2", "T3"))
  weights <- round(stats::runif(n, 0.8, 2.2), 2)
  data.frame(time = time, event = event, group = group, marker = marker, age = age, sex = sex, weights = weights)
}
