#' Tail-aware Kaplan-Meier plot for medical research
#'
#' Draws a publication-oriented Kaplan-Meier curve with optional confidence bands,
#' log-rank p-value, automatic tail truncation when at-risk counts become sparse,
#' and a compact risk table. Optional case weights are supported.
#'
#' @param data Data frame.
#' @param time Character name of survival time column.
#' @param event Character name of event indicator column (0/1).
#' @param group Character name of grouping column.
#' @param weights Optional numeric vector or column name for case weights.
#' @param conf.int Logical; show confidence intervals.
#' @param pval Logical; show p-value.
#' @param risk.table Logical; show risk table.
#' @param min_at_risk Minimum number at risk per group used for automatic tail truncation.
#' @param cut_mode Aggregation rule used when groups differ in how long they remain informative.
#' @param max_time Optional fixed maximum x-axis time. If `NULL`, a tail-aware value is used.
#' @param break_by Optional x-axis break interval.
#' @param palette Optional vector of colors.
#' @param title Optional plot title.
#' @param subtitle Optional subtitle.
#' @param xlab x-axis label.
#' @param ylab y-axis label.
#' @param pval_style Draw the p-value as plain text or label.
#' @param base_size Base font size.
#' @param base_family Base font family.
#'
#' @return A `ggplot2`/`patchwork` object with a `tail_profile` attribute.
#' @export
km_pretty <- function(data,
                      time,
                      event,
                      group,
                      weights = NULL,
                      conf.int = TRUE,
                      pval = TRUE,
                      risk.table = TRUE,
                      min_at_risk = 5,
                      cut_mode = c("all", "any", "median"),
                      max_time = NULL,
                      break_by = NULL,
                      palette = NULL,
                      title = NULL,
                      subtitle = NULL,
                      xlab = "Follow-up time",
                      ylab = "Survival probability",
                      pval_style = c("text", "label"),
                      base_size = 12,
                      base_family = "sans") {
  cut_mode <- match.arg(cut_mode)
  pval_style <- match.arg(pval_style)
  keep <- c(time, event, group)
  if (is.character(weights) && length(weights) == 1) keep <- c(keep, weights)
  .validate_columns(data, keep)

  dat <- data[, unique(keep), drop = FALSE]
  dat <- stats::na.omit(dat)
  dat[[group]] <- as.factor(dat[[group]])
  w <- .resolve_weights(dat, weights)

  form <- stats::as.formula(sprintf("survival::Surv(%s, %s) ~ %s", time, event, group))
  fit <- survival::survfit(form, data = dat, weights = w)

  tp <- tail_profile(fit = fit, min_n = min_at_risk, cut_mode = cut_mode)
  if (is.null(max_time)) {
    max_time <- tp$suggested_max_time
    if (!is.finite(max_time) || max_time <= 0) max_time <- max(dat[[time]], na.rm = TRUE)
  }

  s <- summary(fit)
  if (length(s$time) == 0) stop("No survival data available.", call. = FALSE)
  surv_df <- data.frame(
    time = s$time,
    surv = s$surv,
    upper = s$upper,
    lower = s$lower,
    n.risk = s$n.risk,
    n.event = s$n.event,
    strata = if (is.null(s$strata)) rep("All", length(s$time)) else as.character(s$strata),
    stringsAsFactors = FALSE
  )
  surv_df <- surv_df[surv_df$time <= max_time, , drop = FALSE]
  surv_df <- do.call(rbind, lapply(split(surv_df, surv_df$strata), function(df) {
    rbind(data.frame(time = 0, surv = 1, upper = 1, lower = 1, n.risk = NA, n.event = NA, strata = df$strata[1], stringsAsFactors = FALSE), df)
  }))
  rownames(surv_df) <- NULL

  groups_raw <- unique(surv_df$strata)
  groups_clean <- .clean_strata_labels(groups_raw)
  names(groups_clean) <- groups_raw
  cols <- .color_values(length(groups_raw), palette)
  names(cols) <- groups_clean
  surv_df$strata_label <- factor(groups_clean[surv_df$strata], levels = groups_clean)

  breaks <- if (is.null(break_by)) .pretty_breaks(max_time) else seq(0, max_time, by = break_by)
  breaks <- sort(unique(round(breaks[breaks >= 0 & breaks <= max_time], 8)))
  if (!0 %in% breaks) breaks <- c(0, breaks)

  p <- ggplot2::ggplot(surv_df, ggplot2::aes(x = .data$time, y = .data$surv, color = .data$strata_label))
  if (conf.int) {
    p <- p +
      ggplot2::geom_step(ggplot2::aes(y = .data$upper), linewidth = 0.28, linetype = "dashed", alpha = 0.10, show.legend = FALSE) +
      ggplot2::geom_step(ggplot2::aes(y = .data$lower), linewidth = 0.28, linetype = "dashed", alpha = 0.10, show.legend = FALSE)
  }
  p <- p +
    ggplot2::geom_step(linewidth = 1.0) +
    ggplot2::scale_color_manual(values = cols, drop = FALSE) +
    ggplot2::scale_x_continuous(breaks = breaks, limits = c(0, max_time), expand = ggplot2::expansion(mult = c(0.01, 0.02))) +
    ggplot2::coord_cartesian(ylim = c(0, 1)) +
    ggplot2::labs(title = title, subtitle = subtitle, x = xlab, y = ylab, color = "Group") +
    journal_theme_med(base_size = base_size, base_family = base_family) +
    ggplot2::theme(legend.position = "right", plot.margin = ggplot2::margin(t = 8, r = 8, b = 2, l = 8))

  if (pval && length(unique(dat[[group]])) > 1) {
    p_text <- NULL
    if (is.null(w)) {
      diff_fit <- survival::survdiff(form, data = dat)
      pv <- 1 - stats::pchisq(diff_fit$chisq, df = length(diff_fit$n) - 1)
      p_text <- if (pv < 0.001) "Log-rank p < 0.001" else sprintf("Log-rank p = %.3f", pv)
    } else {
      cox_p <- survival::coxph(form, data = dat, weights = w, ties = "breslow")
      ll_null <- survival::coxph(stats::as.formula(sprintf("survival::Surv(%s, %s) ~ 1", time, event)), data = dat, weights = w, ties = "breslow")
      pv <- .model_compare_p(ll_null, cox_p, family = "cox")
      p_text <- if (pv < 0.001) "Weighted p < 0.001" else sprintf("Weighted p = %.3f", pv)
    }
    if (pval_style == "text") {
      p <- p + ggplot2::annotate("text", x = max_time * 0.60, y = 0.12, label = p_text, hjust = 0, size = 4.1, family = base_family)
    } else {
      p <- p + ggplot2::annotate("label", x = max_time * 0.58, y = 0.12, label = p_text, hjust = 0, size = 3.8, family = base_family, label.size = 0.18, fill = "white")
    }
  }

  attr(p, "tail_profile") <- tp
  if (!risk.table) return(p)

  rs <- summary(fit, times = breaks, extend = TRUE)
  risk_df <- data.frame(
    time = rs$time,
    n.risk = rs$n.risk,
    strata = if (is.null(rs$strata)) rep("All", length(rs$time)) else as.character(rs$strata),
    stringsAsFactors = FALSE
  )
  risk_levels <- rev(groups_clean)
  risk_df$strata_label <- factor(groups_clean[risk_df$strata], levels = risk_levels)
  risk_df$y <- match(as.character(risk_df$strata_label), risk_levels)
  risk_df$label <- .format_nrisk(risk_df$n.risk)

  rt <- ggplot2::ggplot(risk_df, ggplot2::aes(x = .data$time, y = .data$y, label = .data$label, color = .data$strata_label)) +
    ggplot2::geom_text(size = 3.1, family = base_family) +
    ggplot2::annotate("text", x = min(breaks), y = length(risk_levels) + 0.85, label = "At risk", hjust = 0, fontface = "bold", family = base_family, size = 5.8 / ggplot2::.pt, colour = "black") +
    ggplot2::scale_color_manual(values = cols, guide = "none", drop = FALSE) +
    ggplot2::scale_x_continuous(breaks = breaks, limits = c(0, max_time), expand = ggplot2::expansion(mult = c(0.01, 0.02))) +
    ggplot2::scale_y_continuous(breaks = seq_along(risk_levels), labels = risk_levels, limits = c(0.5, length(risk_levels) + 1.0), expand = c(0, 0)) +
    ggplot2::coord_cartesian(clip = "off") +
    ggplot2::labs(x = xlab, y = NULL) +
    ggplot2::theme_void(base_size = base_size, base_family = base_family) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(colour = "black"), axis.title.x = ggplot2::element_text(colour = "black", face = "bold", margin = ggplot2::margin(t = 4)), axis.text.y = ggplot2::element_text(colour = "black", margin = ggplot2::margin(r = 6)), plot.margin = ggplot2::margin(t = 0, r = 8, b = 6, l = 30))

  out <- patchwork::wrap_plots(p, rt, ncol = 1, heights = c(4.3, 1.15))
  attr(out, "tail_profile") <- tp
  out
}

#' Side-by-side Kaplan-Meier comparison for novelty checks
#'
#' Compares an untrimmed display, a default survminer display, and the package's
#' tail-aware display to support methods sections, supplements, or software papers.
#'
#' @inheritParams km_pretty
#' @return A list with combined plot, comparison table, and tail profile.
#' @export
km_compare_tail <- function(data,
                            time,
                            event,
                            group,
                            weights = NULL,
                            min_at_risk = 5,
                            cut_mode = c("all", "any", "median"),
                            palette = NULL,
                            base_size = 11,
                            base_family = "sans") {
  cut_mode <- match.arg(cut_mode)
  keep <- c(time, event, group)
  if (is.character(weights) && length(weights) == 1) keep <- c(keep, weights)
  dat <- stats::na.omit(data[, unique(keep), drop = FALSE])
  w <- .resolve_weights(dat, weights)
  full_max <- max(dat[[time]], na.rm = TRUE)

  p_full <- km_pretty(dat, time = time, event = event, group = group, weights = w, risk.table = FALSE, conf.int = TRUE, min_at_risk = 0, max_time = full_max, palette = palette, title = "No truncation", subtitle = NULL, base_size = base_size, base_family = base_family)
  p_tail <- km_pretty(dat, time = time, event = event, group = group, weights = w, risk.table = FALSE, conf.int = TRUE, min_at_risk = min_at_risk, cut_mode = cut_mode, palette = palette, title = "Tail-aware (medcurveR)", subtitle = NULL, base_size = base_size, base_family = base_family)

  fit <- survival::survfit(stats::as.formula(sprintf("survival::Surv(%s, %s) ~ %s", time, event, group)), data = dat, weights = w)
  survminer_plot <- NULL
  if (requireNamespace("survminer", quietly = TRUE) && is.null(w)) {
    gobj <- survminer::ggsurvplot(fit, data = dat, conf.int = TRUE, risk.table = FALSE)
    survminer_plot <- gobj$plot + ggplot2::labs(title = "survminer default") + journal_theme_med(base_size = base_size, base_family = base_family)
  } else if (requireNamespace("survminer", quietly = TRUE) && !is.null(w)) {
    survminer_plot <- .placeholder_plot("survminer default", "Weighted comparison omitted", base_family = base_family)
  } else {
    survminer_plot <- .placeholder_plot("survminer default", "Install survminer to display", base_family = base_family)
  }

  tp_tail <- attr(p_tail, "tail_profile")
  end_df <- tp_tail$by_group[, c("clean_strata", "end_n_risk")]
  min_end_risk <- min(end_df$end_n_risk, na.rm = TRUE)
  compare_tbl <- data.frame(
    method = c("No truncation", "survminer default", "Tail-aware medcurveR"),
    display_max_time = c(full_max, full_max, tp_tail$summary$final_cutoff),
    rule = c("none", "default", paste0("min_at_risk=", min_at_risk, "; ", cut_mode)),
    min_end_n_risk = c(NA_real_, NA_real_, min_end_risk),
    stringsAsFactors = FALSE
  )

  list(
    plot = patchwork::wrap_plots(p_full, survminer_plot, p_tail, ncol = 3),
    table = compare_tbl,
    tail_profile = tp_tail
  )
}
