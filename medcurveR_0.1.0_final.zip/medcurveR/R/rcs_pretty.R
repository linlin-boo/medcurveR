#' Tail-aware restricted cubic spline plot for medical research
#'
#' Fits a spline model, estimates pointwise effects relative to a reference value,
#' and automatically limits the displayed x-range when tails are sparse. Optional
#' case weights are supported.
#'
#' @param data Data frame.
#' @param x Exposure variable.
#' @param family Model family: `"cox"`, `"logistic"`, or `"linear"`.
#' @param outcome Outcome column for logistic or linear models.
#' @param time Time column for Cox models.
#' @param event Event column for Cox models.
#' @param covariates Optional covariate names.
#' @param weights Optional numeric vector or column name for case weights.
#' @param nk Number of knots used by `Hmisc::rcspline.eval`.
#' @param knots Optional pre-specified knots.
#' @param ref Reference point mode.
#' @param ref_value Reference value when `ref = "value"`.
#' @param trim_quantile Quantiles used for sparse-tail display rules.
#' @param min_tail_n Minimum count retained per tail when using count-aware rules.
#' @param tail_rule Sparse-tail rule: `"hybrid"`, `"quantile"`, or `"count"`.
#' @param conf.level Confidence level.
#' @param bins Histogram bins.
#' @param show_distribution Logical; show lower histogram.
#' @param palette Line color.
#' @param title Plot title.
#' @param subtitle Plot subtitle.
#' @param xlab x-axis label.
#' @param ylab y-axis label.
#' @param show_bounds Logical; shade excluded left/right tails.
#' @param base_size Base font size.
#' @param base_family Base font family.
#'
#' @return A list with plot, fitted model, and standardized tail diagnostics.
#' @export
rcs_pretty <- function(data,
                       x,
                       family = c("cox", "logistic", "linear"),
                       outcome = NULL,
                       time = NULL,
                       event = NULL,
                       covariates = NULL,
                       weights = NULL,
                       nk = 4,
                       knots = NULL,
                       ref = c("median", "mean", "zero", "value"),
                       ref_value = NULL,
                       trim_quantile = c(0.01, 0.99),
                       min_tail_n = 10,
                       tail_rule = c("hybrid", "quantile", "count"),
                       conf.level = 0.95,
                       bins = 30,
                       show_distribution = TRUE,
                       palette = NULL,
                       title = NULL,
                       subtitle = NULL,
                       xlab = NULL,
                       ylab = NULL,
                       show_bounds = TRUE,
                       base_size = 12,
                       base_family = "sans") {
  family <- match.arg(family)
  tail_rule <- match.arg(tail_rule)
  ref <- match.arg(ref)

  needed <- x
  if (family == "cox") needed <- c(needed, time, event)
  if (family %in% c("logistic", "linear")) needed <- c(needed, outcome)
  if (!is.null(covariates)) needed <- c(needed, covariates)
  if (is.character(weights) && length(weights) == 1) needed <- c(needed, weights)
  .validate_columns(data, unique(needed))

  dat <- stats::na.omit(data[, unique(needed), drop = FALSE])
  w <- .resolve_weights(dat, weights)
  x_vec <- dat[[x]]

  tp <- tail_profile(x = x_vec, weights = w, min_n = min_tail_n, trim_quantile = trim_quantile, rule = tail_rule)
  display_bounds <- as.numeric(tp$summary[1, c("lower_bound", "upper_bound")])
  ref_x <- .reference_value(x_vec, ref = ref, ref_value = ref_value)

  basis <- .make_basis(x_vec, nk = nk, knots = knots)
  knot_vec <- attr(basis, "knots")
  dat_basis <- cbind(dat, basis)
  basis_terms <- names(basis)
  rhs <- c(basis_terms, covariates)
  rhs_txt <- paste(rhs, collapse = " + ")
  cov_txt <- if (!is.null(covariates) && length(covariates) > 0) paste(covariates, collapse = " + ") else "1"

  if (family == "cox") {
    form_full <- stats::as.formula(sprintf("survival::Surv(%s, %s) ~ %s", time, event, rhs_txt))
    form_linear <- stats::as.formula(sprintf("survival::Surv(%s, %s) ~ %s + %s", time, event, x, cov_txt))
    form_null <- stats::as.formula(sprintf("survival::Surv(%s, %s) ~ %s", time, event, cov_txt))
    fit_full <- survival::coxph(form_full, data = dat_basis, weights = w, x = TRUE, ties = "breslow")
    fit_linear <- survival::coxph(form_linear, data = dat_basis, weights = w, x = TRUE, ties = "breslow")
    fit_null <- survival::coxph(form_null, data = dat_basis, weights = w, x = TRUE, ties = "breslow")
  } else if (family == "logistic") {
    form_full <- stats::as.formula(sprintf("%s ~ %s", outcome, rhs_txt))
    form_linear <- stats::as.formula(sprintf("%s ~ %s + %s", outcome, x, cov_txt))
    form_null <- stats::as.formula(sprintf("%s ~ %s", outcome, cov_txt))
    fit_full <- stats::glm(form_full, data = dat_basis, weights = w, family = stats::binomial())
    fit_linear <- stats::glm(form_linear, data = dat_basis, weights = w, family = stats::binomial())
    fit_null <- stats::glm(form_null, data = dat_basis, weights = w, family = stats::binomial())
  } else {
    form_full <- stats::as.formula(sprintf("%s ~ %s", outcome, rhs_txt))
    form_linear <- stats::as.formula(sprintf("%s ~ %s + %s", outcome, x, cov_txt))
    form_null <- stats::as.formula(sprintf("%s ~ %s", outcome, cov_txt))
    fit_full <- stats::lm(form_full, data = dat_basis, weights = w)
    fit_linear <- stats::lm(form_linear, data = dat_basis, weights = w)
    fit_null <- stats::lm(form_null, data = dat_basis, weights = w)
  }

  p_overall <- .model_compare_p(fit_null, fit_full, family = family)
  p_nonlinear <- .model_compare_p(fit_linear, fit_full, family = family)

  grid <- seq(min(x_vec, na.rm = TRUE), max(x_vec, na.rm = TRUE), length.out = 240)
  pred_dat <- .make_prediction_data(dat, x = x, covariates = covariates, grid = grid)
  pred_basis <- .make_basis(pred_dat[[x]], knots = knot_vec)
  pred_full <- cbind(pred_dat, pred_basis)

  ref_dat <- .make_prediction_data(dat, x = x, covariates = covariates, grid = ref_x)
  ref_basis <- .make_basis(ref_dat[[x]], knots = knot_vec)
  ref_full <- cbind(ref_dat, ref_basis)

  rhs_formula <- stats::as.formula(paste("~", paste(c(basis_terms, covariates), collapse = " + ")))
  X_pred <- stats::model.matrix(rhs_formula, data = pred_full)
  X_ref <- stats::model.matrix(rhs_formula, data = ref_full)

  beta <- stats::coef(fit_full)
  beta <- beta[!is.na(beta)]
  coef_names <- names(beta)
  V <- stats::vcov(fit_full)
  V <- V[coef_names, coef_names, drop = FALSE]
  X_pred <- .align_matrix(X_pred, coef_names)
  X_ref <- .align_matrix(X_ref, coef_names)

  eta_pred <- as.vector(X_pred %*% beta)
  eta_ref <- as.vector(X_ref %*% beta)
  X_diff <- sweep(X_pred, 2, X_ref[1, ], "-")
  se <- sqrt(diag(X_diff %*% V %*% t(X_diff)))
  z_crit <- stats::qnorm(1 - (1 - conf.level) / 2)
  delta <- eta_pred - eta_ref

  if (family == "linear") {
    effect <- delta
    lower <- delta - z_crit * se
    upper <- delta + z_crit * se
    ref_line <- 0
    if (is.null(ylab)) ylab <- "Difference in outcome"
  } else {
    effect <- exp(delta)
    lower <- exp(delta - z_crit * se)
    upper <- exp(delta + z_crit * se)
    ref_line <- 1
    if (is.null(ylab)) ylab <- if (family == "cox") "Hazard ratio" else "Odds ratio"
  }

  pred_df <- data.frame(x = grid, effect = effect, lower = lower, upper = upper, stringsAsFactors = FALSE)
  pred_df$in_display <- pred_df$x >= display_bounds[1] & pred_df$x <= display_bounds[2]
  pred_df_display <- pred_df[pred_df$in_display, , drop = FALSE]

  if (is.null(xlab)) xlab <- x
  if (is.null(palette)) palette <- "#1B4F72"

  label_overall <- if (isTRUE(p_overall < 0.001)) "P-overall < 0.001" else sprintf("P-overall = %.3f", p_overall)
  label_nonlinear <- if (isTRUE(p_nonlinear < 0.001)) "P-nonlinear < 0.001" else sprintf("P-nonlinear = %.3f", p_nonlinear)
  label_tail <- sprintf("Rule: %s | Bounds: %.2f to %.2f", tail_rule, display_bounds[1], display_bounds[2])

  main_plot <- ggplot2::ggplot(pred_df, ggplot2::aes(x = .data$x, y = .data$effect))
  if (show_bounds) {
    main_plot <- main_plot +
      ggplot2::annotate("rect", xmin = min(pred_df$x), xmax = display_bounds[1], ymin = -Inf, ymax = Inf, fill = "grey70", alpha = 0.12) +
      ggplot2::annotate("rect", xmin = display_bounds[2], xmax = max(pred_df$x), ymin = -Inf, ymax = Inf, fill = "grey70", alpha = 0.12)
  }
  main_plot <- main_plot +
    ggplot2::geom_ribbon(data = pred_df_display, ggplot2::aes(ymin = .data$lower, ymax = .data$upper), fill = palette, alpha = 0.14) +
    ggplot2::geom_line(data = pred_df_display, linewidth = 1.0, colour = palette) +
    ggplot2::geom_vline(xintercept = ref_x, linetype = "dashed", linewidth = 0.55) +
    ggplot2::geom_hline(yintercept = ref_line, linetype = "dotted", linewidth = 0.55) +
    ggplot2::annotate("text", x = display_bounds[1] + 0.03 * diff(display_bounds), y = max(pred_df_display$upper, na.rm = TRUE), hjust = 0, vjust = 1, label = paste(label_overall, label_nonlinear, label_tail, sep = "\n"), size = 3.6, family = base_family) +
    ggplot2::labs(title = title, subtitle = subtitle, x = xlab, y = ylab) +
    ggplot2::coord_cartesian(xlim = range(pred_df$x)) +
    journal_theme_med(base_size = base_size, base_family = base_family)

  if (!show_distribution) {
    return(list(fit = fit_full, p_overall = p_overall, p_nonlinear = p_nonlinear, display_bounds = display_bounds, reference = ref_x, tail_profile = tp, plot_data = pred_df, plot = main_plot))
  }

  hist_df <- data.frame(x = x_vec)
  dist_plot <- ggplot2::ggplot(hist_df, ggplot2::aes(x = .data$x)) +
    ggplot2::geom_histogram(bins = bins, fill = "grey75", colour = "white") +
    ggplot2::annotate("rect", xmin = min(pred_df$x), xmax = display_bounds[1], ymin = -Inf, ymax = Inf, fill = "grey70", alpha = 0.12) +
    ggplot2::annotate("rect", xmin = display_bounds[2], xmax = max(pred_df$x), ymin = -Inf, ymax = Inf, fill = "grey70", alpha = 0.12) +
    ggplot2::geom_vline(xintercept = ref_x, linetype = "dashed", linewidth = 0.55) +
    ggplot2::coord_cartesian(xlim = range(pred_df$x)) +
    ggplot2::labs(x = xlab, y = "Count") +
    ggplot2::theme_bw(base_size = base_size - 1, base_family = base_family) +
    ggplot2::theme(panel.grid = ggplot2::element_blank(), plot.margin = ggplot2::margin(t = -6, r = 5.5, b = 5.5, l = 5.5))

  list(
    fit = fit_full,
    p_overall = p_overall,
    p_nonlinear = p_nonlinear,
    display_bounds = display_bounds,
    reference = ref_x,
    tail_profile = tp,
    plot_data = pred_df,
    plot = patchwork::wrap_plots(main_plot, dist_plot, ncol = 1, heights = c(3.8, 1.2))
  )
}

#' Side-by-side spline comparison for novelty checks
#'
#' Compares a full-range spline display with the package's tail-aware display and
#' returns a compact summary table.
#'
#' @inheritParams rcs_pretty
#' @return A list with combined plot and comparison table.
#' @export
rcs_compare_tail <- function(data,
                             x,
                             family = c("cox", "logistic", "linear"),
                             outcome = NULL,
                             time = NULL,
                             event = NULL,
                             covariates = NULL,
                             weights = NULL,
                             min_tail_n = 10,
                             tail_rule = c("hybrid", "quantile", "count"),
                             nk = 4,
                             title_prefix = NULL,
                             base_size = 11,
                             base_family = "sans") {
  family <- match.arg(family)
  tail_rule <- match.arg(tail_rule)

  full_out <- rcs_pretty(data = data, x = x, family = family, outcome = outcome, time = time, event = event, covariates = covariates, weights = weights, nk = nk, min_tail_n = 1, tail_rule = "count", title = paste(title_prefix %||% x, "- Full range"), show_distribution = TRUE, show_bounds = FALSE, base_size = base_size, base_family = base_family)
  tail_out <- rcs_pretty(data = data, x = x, family = family, outcome = outcome, time = time, event = event, covariates = covariates, weights = weights, nk = nk, min_tail_n = min_tail_n, tail_rule = tail_rule, title = paste(title_prefix %||% x, "- Tail-aware"), show_distribution = TRUE, show_bounds = TRUE, base_size = base_size, base_family = base_family)

  compare_tbl <- data.frame(
    method = c("Full range", "Tail-aware"),
    lower_bound = c(min(full_out$plot_data$x, na.rm = TRUE), tail_out$tail_profile$summary$lower_bound),
    upper_bound = c(max(full_out$plot_data$x, na.rm = TRUE), tail_out$tail_profile$summary$upper_bound),
    left_tail_n = c(0, tail_out$tail_profile$summary$left_tail_n),
    right_tail_n = c(0, tail_out$tail_profile$summary$right_tail_n),
    rule = c("none", tail_rule),
    stringsAsFactors = FALSE
  )

  list(
    plot = patchwork::wrap_plots(full_out$plot, tail_out$plot, ncol = 2),
    table = compare_tbl,
    tail_profile = tail_out$tail_profile
  )
}
