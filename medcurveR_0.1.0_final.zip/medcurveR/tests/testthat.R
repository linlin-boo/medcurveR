library(testthat)
library(medcurveR)

test_check("medcurveR")
