test_that("km_pretty returns object", {
  d <- sim_surv_data(120)
  p <- km_pretty(d, time = "time", event = "event", group = "group", risk.table = FALSE)
  expect_true(inherits(p, "ggplot"))
})

test_that("rcs_pretty returns list", {
  d <- sim_surv_data(120)
  out <- rcs_pretty(d, x = "marker", time = "time", event = "event", covariates = c("age", "sex"), family = "cox")
  expect_true(is.list(out))
  expect_true("plot" %in% names(out))
})
